<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Taller 1 PHP</title>
</head>
<body>
    <?php
        echo "------------------- Definición de variables y constantes ----------------------<br>";
        //Variables
        $nombre = "Pedro"; // variable tipo texto;
        $apellido = "Perez"; // variable tipo texto;
        $edad = 45; // variable numérica ;
        echo "El señor ". $nombre . " " . $apellido . " tiene una edad de ". $edad . " años. " ;

        //Constantes
        define("SENA", "Servicio Nacional de Aprendizaje");
        echo "<br>Esta es una constante: ", SENA, "<br>";

        echo "<br>------------------------------- Arreglos ---------------------------------<br>";
        //Arreglos
        //con clave:
        $arreglo = [
            "Nombre" => "Pedro",
            "Apellido" => "Perez",
           ];
        echo "Buenos días ". $arreglo["Nombre"] . " " . $arreglo["Apellido"] . "<br>";
        //sin clave        
        $arreglo1 = [ "Jacinto", "Jose", "Pepita", "Mendieta" ] ;
        echo "Buenos días ". $arreglo1[0] ." ". $arreglo1[1] ." ".$arreglo1[2] ." ".$arreglo1[3] . "<br>";
        var_dump($arreglo1); 
        echo "<br>";
        //Estructuras de control
        //Condicional
        echo "<br>------------------------ Condicional sencillo --------------------------<br>";
        $a = 8;
        $b = 3;
        if( $a < $b ){
            echo "a es menor que b<br>";
        } else {
            echo "a es mayor que b<br>";
        };
        //While
        echo "<br>--------- Ciclo While para generar numeros de 1 a 10 -------------------<br>";
        $i = 1;
        while($i<=10){
            echo "el valor de i es: ", $i, "<br>";
            $i++;
        }
        //Do While
        echo "<br>------------ Ciclo Do While para generar numeros de 1 a 5 -----------------<br>";
        $i = 1;
        do{
            echo "el valor de i es: ", $i, "<br>";
            $i++;
        }while($i<=5);
        //Do While
        echo "<br>-------------------- Ejemplo del ciclo for --------------------------<br>";
        for($i=1;$i<=7;$i++){
            echo "Linea ".$i."<br>";
        };
        //Switch case
        echo "<br>--------------- Ejemplo del uso del comando switch-------------------<br>";
        $i=5;
        switch ($i)
        {
            case 1:
                echo "Uno<br>";
                break;
            case 2:
                echo "Dos<br>";
                break;
            case 3:
                echo "Tres<br>";
                break;
            case 4:
                echo "Cuatro<br>";
                break;
            default:
                echo "Solo me programaron entre uno y cuatro<br>";
        };
        //Foreach
        echo "<br>--------------- Ciclo foreach para recorrer arreglos -------------------<br>";
        $j=0;
        foreach ($arreglo1 as $elemento)
        {
            echo "$j: $elemento <br>";
            $j++;
        };
        echo "<br><h4>Arreglo con llaves:</h4>";
        $arreglo2 = [
            "Primer_Nombre" => "Pedro",
            "Segundo_Nombre" => "Pablo",
            "Primer_Apellido" => "Perez",
            "Segundo_Apellido" => "Pereira"
        ];
        
        foreach($arreglo2 as $llave => $elemento)
        {
            echo "$llave: $elemento <br>";
        };

        //Funciones
        echo "<br>--------------- Función para mostrar el nombre del día -------------------<br>";
        function nombre_dia($dia){
            switch($dia){
                case 1: return "Domingo";
                case 2: return "Lunes";
                case 3: return "Martes";
                default: return "Solo se de domingo a martes";
            };
        };
        echo nombre_dia(4) . "<br>";
    ?>
    <h4>------------------------------- Formulario ------------------- </h4>

    <form action="programa1.php" method=post>
        Nombre: <input type="text" name="nombre"><br>
        Apellido: <input type="text" name="apellido"><br>
        <input type=submit value="Enviar">

    </form>

    <h4>------------------------------- Conexión a BD ------------------- </h4>
    <?php
        include "db_connection.php";
    ?>
</body>
</html>