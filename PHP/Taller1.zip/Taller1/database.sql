create database adsi ;
create table ciudades ( codigo text, nombre text ) ;
insert into ciudades ( codigo, nombre ) values ( "05001", "MEDELLIN" );
insert into ciudades ( codigo, nombre ) values ( "05002", "ABEJORRAL" );
insert into ciudades ( codigo, nombre ) values ( "05004", "ABRIAQUI" );
insert into ciudades ( codigo, nombre ) values ( "05021", "ALEJANDRIA" );