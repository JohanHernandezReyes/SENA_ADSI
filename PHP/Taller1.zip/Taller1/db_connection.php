<?php
    $conn = new mysqli("localhost:3306", "root", "12345", "adsi" ) ;
    if( $conn->connect_errno ) {
        echo "Falla al conectarse a Mysql ( ". $conn->connect_errno . ") <br>";
        exit();
    $conn->connect_error ;
    } else {
        echo "Conexión exitosa!." . $conn->host_info. "<br>";
        
    };

    if($resultado = $conn->query("SELECT codigo, nombre FROM ciudades;")){
        while($registro = $resultado->fetch_assoc())
        {
            echo $registro["codigo"] . " " . $registro["nombre"] . "<br>";
        };
    }
    else{
        echo "error";
    };

    $resultado->free();
    $conn->close();

?>